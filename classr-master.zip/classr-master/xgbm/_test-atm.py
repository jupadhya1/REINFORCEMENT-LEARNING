import pandas as pd
import sys
from sklearn import preprocessing as preproc
from sklearn import linear_model as lm
from sklearn import metrics as metrics
from sklearn.feature_extraction import text as txt
import string
import numpy as np
import xgboost as xgb
from scipy.sparse import hstack
from subprocess import call


def create_paragraph_vectors(in_text_file, 
   in_vocab, 
   in_layer0,
   in_layer1,
   out_vec_csv,
   dim=200, 
   model="DM", 
   objective="negative", 
   negative_samples=8,
   window=4,
   subsample=0.001,
   initial_alpha=0.025,
   threads=4,
   iters=20):
   """Invokes PV to create a vector CSV from the input text file""" 
   call(["pv/pv", "-train", in_text_file, 
      "-read-vocab", in_vocab,
      "-dim", str(dim), 
      "-read-layer0", in_layer0,
      "-read-layer1", in_layer1,
      "-binary", "0",
      "-dm", "1" if model=="DM" else "0",
      "-alpha", str(initial_alpha),
      "-window", str(window),
      "-sample", str(subsample),
      "-hs", "1" if objective=="hs" else "0",
      "-negative", str(negative_samples),
      "-threads", str(threads),
      "-iter", str(iters),
      "-empty-paragraphs", "1",
      "-freeze-layer1", "1",
      "-freeze-words", "1",
      "-output", out_vec_csv])

def remove_non_vocab_words(x, vocab):
   ticket = ''
   for word in x.split(' '):
      if (word in vocab): ticket += ' ' + word
   return ticket.strip()

def train_xgbm(in_csv, in_vocab_file, out_model_file, in_vec1_csv='', in_vec2_csv='', 
   in_vec3_csv='', in_vec4_csv='', n_boost=1000, in_text_col='CLEAN_COMBINED', 
   in_class_col='TICKETCLASS', eta=0.01, max_depth=4, threads=12, eval_split_size=0.2,
   test_account='', out_csv='', ngram_range=(1,1)):

   """Takes an input CSV and paragraph vectors, trains a gradient boosted model on
   a training set combined from the paragraph vectors and bag-of-words, and saves
   the model to a specified file. The function can evaluate the model on a test set,
   if specified."""

   print 'Input CSV         :', in_csv
   print 'Input text col    :', in_text_col
   print 'Input class col   :', in_class_col
   if in_vec1_csv != '': print 'Input vectors (1) :', in_vec1_csv
   if in_vec2_csv != '': print 'Input vectors (2) :', in_vec2_csv
   if in_vec3_csv != '': print 'Input vectors (3) :', in_vec3_csv
   if in_vec4_csv != '': print 'Input vectors (4) :', in_vec4_csv
   print 'Input vocab       :', in_vocab_file
   print 'N-grams           :', str(ngram_range)
   print 'Boosting rounds   :', n_boost
   print 'ETA               :', eta
   print 'Max depth         :', max_depth
   print 'Evaluation split  :', (eval_split_size*100), '%'
   print 'Threads           :', threads
   print 'Output model      :', out_model_file
   if out_csv != '': print 'Output CSV        :', out_csv
   if test_account != '': print 'Test account      :', test_account

   # read input
   tickets_csv = pd.read_csv(in_csv, na_filter=False)
   tickets_csv[in_class_col] = tickets_csv[in_class_col].str.lower()
   if (in_vec1_csv != '') :
      vec_csv = pd.read_csv(in_vec1_csv)
      if in_vec2_csv != '' : vec_csv = vec_csv.merge(pd.read_csv(in_vec2_csv), on='paragraph_id')
      if in_vec3_csv != '' : vec_csv = vec_csv.merge(pd.read_csv(in_vec3_csv), on='paragraph_id', suffixes=['_2','_3'])
      if in_vec4_csv != '' : vec_csv = vec_csv.merge(pd.read_csv(in_vec4_csv), on='paragraph_id', suffixes=['_4','_5'])

   # split training and test set (if applicable)
   if test_account == '': 
      tickets_train = tickets_csv
      if (in_vec1_csv != '') : vec_train = vec_csv
   else:
      tickets_train = tickets_csv[(tickets_csv['ACCOUNT']!=test_account)]
      if (in_vec1_csv != '') : vec_train = vec_csv[(tickets_csv['ACCOUNT']!=test_account)]
      tickets_test = tickets_csv[tickets_csv['ACCOUNT']==test_account]
      if (in_vec1_csv != '') : vec_test = vec_csv[tickets_csv['ACCOUNT']==test_account]

   ticketclass_encoder = preproc.LabelEncoder()
   ticketclass_encoder.fit_transform(tickets_csv[in_class_col])

   # read vocab
   with open(in_vocab_file) as f:
      vocab = f.readlines()
   vocab = [line[:-1] for line in vocab]

   if (ngram_range == (1,1)):
      vectorizer = txt.TfidfVectorizer(stop_words='english', vocabulary=vocab)
   else:
      print "Removing non-vocab words"
      vocab_set = frozenset(vocab)
      tickets_train[in_text_col] = tickets_train[in_text_col].apply(remove_non_vocab_words, args=(vocab_set, ))
      vectorizer = txt.TfidfVectorizer(stop_words='english', ngram_range=ngram_range)

   # prepare training data
   X_train = vectorizer.fit_transform(tickets_train[in_text_col])
   print X_train.shape
   # concatenate PVs (if applicable)
   if (in_vec1_csv != '') : 
      X_train = hstack((X_train, np.array(vec_train.iloc[:,1:].as_matrix()).astype(np.float32))).tocsr()
   y_train = ticketclass_encoder.transform(tickets_train[in_class_col])
   # split training/eval sets
   rng = np.random.RandomState(444)
   train_or_eval = np.random.rand(y_train.shape[0]) >= eval_split_size
   dtrain = xgb.DMatrix(X_train[train_or_eval==True], label=y_train[train_or_eval==True])
   deval = xgb.DMatrix(X_train[train_or_eval==False], label=y_train[train_or_eval==False])

   # prepare test data (if applicable)
   if test_account != '': 
      X_test = vectorizer.transform(tickets_test[in_text_col])
      # concatenate PVs (if applicable)
      if (in_vec1_csv != '') :
         X_test = hstack((X_test, np.array(vec_test.iloc[:,1:].as_matrix()).astype(np.float32))).tocsr()
      y_test = ticketclass_encoder.transform(tickets_test[in_class_col])
      dtest = xgb.DMatrix(X_test, label=y_test)

   print 'Training samples  :', tickets_train[train_or_eval==True].count()
   print 'Eval samples      :', tickets_train[train_or_eval==False].count()
   if test_account != '': print 'Test samples      :', tickets_test[in_class_col].count()

   # setup parameters for xgboost
   param = {}
   param['booster'] = 'gbtree'
   param['objective'] = 'multi:softprob'
   param['eval_metric'] = 'merror'
   param['eta'] = eta
   param['max_depth'] = max_depth
   param['silent'] = 0
   param['nthread'] = threads
   param['num_class'] = len(pd.Series.unique(tickets_csv[in_class_col]))
   
   watchlist = [(deval, 'eval'), (dtrain,'train')]

   # train booster
   bst = xgb.train(param, dtrain, n_boost, watchlist)

   # save model
   bst.save_model(out_model_file)

   if test_account != '': 
      # get prediction (probabilities)
      y_prob = bst.predict(dtest)
      y_prob = pd.DataFrame(y_prob, columns=ticketclass_encoder.inverse_transform(range(y_prob.shape[1])), index=tickets_test.index)
      y_pred = np.argmax(y_prob, axis=1)
      print metrics.confusion_matrix(y_test, y_pred)
      print "Accuracy: %f" % metrics.accuracy_score(y_test, y_pred)
      tickets_test = pd.concat((tickets_test, y_prob), axis=1)
      tickets_test['PRED_'+in_class_col] = pd.DataFrame(ticketclass_encoder.inverse_transform(y_pred.astype(int)), index=tickets_test.index)
      tickets_test.to_csv(out_csv)



def classify_xgbm(in_model_file, in_csv, in_vocab_file, in_vec1_csv, in_vec2_csv, in_vec3_csv, in_vec4_csv,
   in_text_col='CLEAN_COMBINED', out_class_col='TICKETCLASS', ngram_range=(1,1), orig_input='', 
   orig_in_text_col='CLEAN_COMBINED',
   classes=["Disk", "Nonactionable", "Other", "Performance", "Process", "Server unavailable"],
   verbose=False):
   """Loads a CSV file and a gradient boosted classifier model, classifies 
   the specified input text column and saves the output to a CSV"""
   
   print 'Reading GBM model'
   bst = xgb.Booster(model_file=in_model_file)
   
   print 'Reading CSV'
   tickets_csv = pd.read_csv(in_csv, na_filter=False)
   print 'Tickets to classify:', tickets_csv[in_text_col].count()
   
   if in_vec1_csv != '' : 
      print 'Reading PVs'
      vec_csv = pd.read_csv(in_vec1_csv)
   if in_vec2_csv != '' : vec_csv = vec_csv.merge(pd.read_csv(in_vec2_csv), on='paragraph_id')
   if in_vec3_csv != '' : vec_csv = vec_csv.merge(pd.read_csv(in_vec3_csv), on='paragraph_id', suffixes=['_2','_3'])
   if in_vec4_csv != '' : vec_csv = vec_csv.merge(pd.read_csv(in_vec4_csv), on='paragraph_id', suffixes=['_4','_5'])
   
   with open(in_vocab_file) as f:
      vocab = f.readlines()
   vocab = [line[:-1] for line in vocab]
   
   if (ngram_range == (1,1)):
      print 'Generating tf-idf matrix'
      vectorizer = txt.TfidfVectorizer(stop_words='english', vocabulary=vocab)
      X_in = vectorizer.fit_transform(tickets_csv[in_text_col])
   else:
      if orig_input == '': 
         print 'Using ngrams', ngram_range, 'but no --orig-input specified'
         sys.exit(2)
      print "Removing non-vocab words"
      vocab_set = frozenset(vocab)
      orig_tickets_csv = pd.read_csv(orig_input, na_filter=False)
      orig_tickets_csv[orig_in_text_col] = orig_tickets_csv[orig_in_text_col].apply(remove_non_vocab_words, args=(vocab_set,))
      tickets_csv[in_text_col] = tickets_csv[in_text_col].apply(remove_non_vocab_words, args=(vocab_set,))
      print 'Generating tf-idf matrix'
      vectorizer = txt.TfidfVectorizer(stop_words='english', ngram_range=ngram_range)
      vectorizer.fit(orig_tickets_csv[orig_in_text_col])
      X_in = vectorizer.transform(tickets_csv[in_text_col])
   
   if in_vec1_csv != '' : X_in = hstack((X_in, np.array(vec_csv.iloc[:,1:].as_matrix()).astype(np.float32))).tocsr()
   ticketclass_encoder = preproc.LabelEncoder()
   ticketclass_encoder.fit_transform(classes)
   
   np.random.seed(444)
   rng = np.random.RandomState(444)
   
   print 'Classifying'
   dpred = xgb.DMatrix(X_in)
   y_prob = bst.predict(dpred)
   print 'Writing results'
   y_pred = np.argmax(y_prob, axis=1)
   y_prob = pd.DataFrame(y_prob, columns=ticketclass_encoder.inverse_transform(range(y_prob.shape[1])), index=tickets_csv.index)
   
   tickets_csv = pd.concat((tickets_csv, y_prob), axis=1)
   tickets_csv[out_class_col] = pd.DataFrame(ticketclass_encoder.inverse_transform(y_pred.astype(int)), index=tickets_csv.index)
   return tickets_csv

