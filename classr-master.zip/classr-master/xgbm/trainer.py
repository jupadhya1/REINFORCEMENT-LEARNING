import pandas as pd
import sys, getopt
import string
import algorithms

def invoke_xgbmpv_training(
   in_csv,
   in_voc,
   out_csv,
   in_vec1 = '',
   in_vec2 = '',
   in_vec3 = '',
   in_vec4 = '',
   clean_text_col = 'CLEAN_COMBINED',
   test_account = '',
   out_model = '',
   n_boost = 1000,
   eta = 0.01,
   max_depth = 4,
   eval_split_size = 0.2,
   max_ngram = 1):
   
   algorithms.train_xgbm(
      in_csv = in_csv, 
      in_vocab_file = in_voc, 
      in_vec1_csv = in_vec1,
      in_vec2_csv = in_vec2,
      in_vec3_csv = in_vec3,
      in_vec4_csv = in_vec4,
      out_model_file = out_model,
      n_boost = n_boost,
      eta = eta,
      max_depth = max_depth,
      eval_split_size = eval_split_size,
      ngram_range=(1,max_ngram))
