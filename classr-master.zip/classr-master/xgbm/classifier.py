import pandas as pd
import sys, getopt
import string
import os.path
import csv

import prep
import algorithms

def run(
   in_csv,
   in_voc,
   out_csv,
   in_model,
   pv_weights_dir,         
   vec_desc_dm,            
   vec_desc_dbow,          
   vec_res_dm,             
   vec_res_dbow,           
   pv_desc_txt,            
   pv_res_txt,             
   desc_col,               
   res_col,                
   clean_desc_out_col,     
   clean_res_out_col,      
   clean_combined_out_col, 
   ticketclass_out_col,    
   dm_dim,                 
   dm_objective,           
   dm_negative_samples,    
   dm_window,              
   dm_subsample,           
   dm_iters,               
   dbow_dim,               
   dbow_objective,         
   dbow_negative_samples,  
   dbow_window,            
   dbow_subsample,         
   dbow_iters,             
   threads,                
   max_ngram,              
   orig_input,
   job_context):
   
   log = job_context.logger

   in_pv_desc_voc =         os.path.join(pv_weights_dir, 'pasir43-desc.voc')
   in_pv_res_voc =          os.path.join(pv_weights_dir, 'pasir43-res.voc')
   in_pv_desc_dm_layer0 =   os.path.join(pv_weights_dir, 'pasir43-desc-dm.lay0.dat')
   in_pv_desc_dm_layer1 =   os.path.join(pv_weights_dir, 'pasir43-desc-dm.lay1.dat')
   in_pv_desc_dbow_layer0 = os.path.join(pv_weights_dir, 'pasir43-desc-dbow.lay0.dat')
   in_pv_desc_dbow_layer1 = os.path.join(pv_weights_dir, 'pasir43-desc-dbow.lay1.dat')
   in_pv_res_dm_layer0 =    os.path.join(pv_weights_dir, 'pasir43-res-dm.lay0.dat')
   in_pv_res_dm_layer1 =    os.path.join(pv_weights_dir, 'pasir43-res-dm.lay1.dat')
   in_pv_res_dbow_layer0 =  os.path.join(pv_weights_dir, 'pasir43-res-dbow.lay0.dat')
   in_pv_res_dbow_layer1 =  os.path.join(pv_weights_dir, 'pasir43-res-dbow.lay1.dat')
   
   log.info('Input CSV                        : %s' % in_csv)
   log.info('Input vocab                      : %s' % in_voc)
   log.info('Input model                      : %s' % in_model)
   log.info('Input description column         : %s' % desc_col)
   log.info('Input resolution column          : %s' % res_col)
   log.info('Output clean desc. col.          : %s' % clean_desc_out_col)
   log.info('Output clean res. col.           : %s' % clean_res_out_col)
   log.info('Output clean combined col.       : %s' % clean_combined_out_col)
   log.info('Output ticketclass col.          : %s' % ticketclass_out_col)
   log.info('Output CSV                       : %s' % out_csv)
   log.info('PV desc. training file           : %s' % pv_desc_txt)
   log.info('PV res. training file            : %s' % pv_res_txt)
   log.info('Description DM vectors           : %s' % vec_desc_dm)
   log.info('Description DBOW vectors         : %s' % vec_desc_dbow)
   log.info('Resolution DM vectors            : %s' % vec_res_dm)
   log.info('Resolution DBOW vectors          : %s' % vec_res_dbow)
   log.info('PV weights directory             : %s' % pv_weights_dir)
   log.info('PV description vocab             : %s' % in_pv_desc_voc)
   log.info('PV resolution vocab              : %s' % in_pv_res_voc)
   log.info('PV DM layer0 weights for desc.   : %s' % in_pv_desc_dm_layer0)
   log.info('PV DM layer1 weights for desc.   : %s' % in_pv_desc_dm_layer1)
   log.info('PV DBOW layer0 weights for desc. : %s' % in_pv_desc_dbow_layer0)
   log.info('PV DBOW layer1 weights for desc. : %s' % in_pv_desc_dbow_layer1)
   log.info('PV DM layer0 weights for res.    : %s' % in_pv_res_dm_layer0)
   log.info('PV DM layer1 weights for res.    : %s' % in_pv_res_dm_layer1)
   log.info('PV DBOW layer0 weights for res.  : %s' % in_pv_res_dbow_layer0)
   log.info('PV DBOW layer1 weights for res.  : %s' % in_pv_res_dbow_layer1)
   log.info('Threads                          : %s' % threads)
   log.info('N-grams                          : %s' % max_ngram)
   if orig_input !='': log.info('Original text input              : %s' % orig_input)
   
   job_context.update_progress(3, 'Verifying and cleansing ticket text')
   tickets_csv = prep.open_and_clean_ticket_csv(in_csv,
                                  desc_col=desc_col,
                                  res_col=res_col,
                                  clean_desc_col=clean_desc_out_col,
                                  clean_res_col=clean_res_out_col,
                                  clean_combined_col=clean_combined_out_col,
                                  verbose=True)
   tickets_csv.to_csv(out_csv, quoting=csv.QUOTE_NONNUMERIC, encoding='utf-8')
   
   # create PVs (if applicable)
   # create training file of cleaned descriptions for pv (if applicable)
   if ((vec_desc_dm != '' or vec_desc_dbow != '') and \
      not os.path.isfile(pv_desc_txt)) :
      job_context.update_progress(4, 'Preparing description for paragraph vector training')
      prep.write_text_for_pv(tickets_csv[clean_desc_out_col], pv_desc_txt)
   # description - DM
   if (vec_desc_dm != '' and not os.path.isfile(vec_desc_dm)) :
      job_context.update_progress(5, 'Training paragraph vectors (description - DM)')
      algorithms.create_paragraph_vectors(in_text_file=pv_desc_txt,
                      in_vocab         = in_pv_desc_voc,
                      in_layer0        = in_pv_desc_dm_layer0,
                      in_layer1        = in_pv_desc_dm_layer1,
                      out_vec_csv      = vec_desc_dm,
                      dim              = dm_dim,
                      model            = "DM",
                      objective        = dm_objective,
                      negative_samples = dm_negative_samples,
                      window           = dm_window,
                      subsample        = dm_subsample,
                      iters            = dm_iters,
                      threads          = threads)
   # description - DBOW
   if (vec_desc_dbow != '' and not os.path.isfile(vec_desc_dbow)) :
      job_context.update_progress(25, 'Training paragraph vectors (description - DBOW)')
      algorithms.create_paragraph_vectors(in_text_file=pv_desc_txt,
                      in_vocab         = in_pv_desc_voc,
                      in_layer0        = in_pv_desc_dbow_layer0,
                      in_layer1        = in_pv_desc_dbow_layer1,
                      out_vec_csv      = vec_desc_dbow,
                      dim              = dbow_dim,
                      model            = "DBOW",
                      objective        = dbow_objective,
                      negative_samples = dbow_negative_samples,
                      window           = dbow_window,
                      subsample        = dbow_subsample,
                      iters            = dbow_iters,
                      threads          = threads)
   
   # create training file of cleaned resolutions for pv (if applicable)
   if ((vec_res_dm != '' or vec_res_dbow != '') and \
      not (os.path.isfile(pv_res_txt))) :
      job_context.update_progress(25, 'Preparing resolution for paragraph vector training')
      prep.write_text_for_pv(tickets_csv[clean_res_out_col], pv_res_txt)
   # resolution - DM
   if (vec_res_dm != '' and not os.path.isfile(vec_res_dm)) :
      job_context.update_progress(45, 'Training paragraph vectors (resolution - DM)')
      algorithms.create_paragraph_vectors(in_text_file=pv_res_txt,
                      in_vocab         = in_pv_res_voc,
                      in_layer0        = in_pv_res_dm_layer0,
                      in_layer1        = in_pv_res_dm_layer1,
                      out_vec_csv      = vec_res_dm,
                      dim              = dm_dim,
                      model            = "DM",
                      objective        = dm_objective,
                      negative_samples = dm_negative_samples,
                      window           = dm_window,
                      subsample        = dm_subsample,
                      iters            = dm_iters,
                      threads          = threads)
   # resolution - DBOW
   if (vec_res_dbow != '' and not os.path.isfile(vec_res_dbow)) :
      job_context.update_progress(65, 'Training paragraph vectors (resolution - DBOW)')
      algorithms.create_paragraph_vectors(in_text_file=pv_res_txt,
                      in_vocab         = in_pv_res_voc,
                      in_layer0        = in_pv_res_dbow_layer0,
                      in_layer1        = in_pv_res_dbow_layer1,
                      out_vec_csv      = vec_res_dbow,
                      dim              = dbow_dim,
                      model            = "DBOW",
                      objective        = dbow_objective,
                      negative_samples = dbow_negative_samples,
                      window           = dbow_window,
                      subsample        = dbow_subsample,
                      iters            = dbow_iters,
                      threads          = threads)
   
   job_context.update_progress(85, 'Predicting ticket labels using XGBM')
   tickets_csv = algorithms.classify_xgbm(in_model_file = in_model,
      in_csv        = out_csv, 
      in_vocab_file = in_voc, 
      in_vec1_csv   = vec_desc_dm,
      in_vec2_csv   = vec_desc_dbow,
      in_vec3_csv   = vec_res_dm,
      in_vec4_csv   = vec_res_dbow,
      in_text_col   = clean_combined_out_col,
      out_class_col = ticketclass_out_col,
      ngram_range   = (1,max_ngram),
      orig_input    = orig_input)
   
   job_context.update_progress(98, 'Saving results')
   tickets_csv.to_csv(out_csv, quoting=csv.QUOTE_NONNUMERIC, encoding='utf-8')
   return tickets_csv


if __name__ == "__main__":
   main(sys.argv[1:])

