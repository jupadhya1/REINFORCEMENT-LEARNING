
import pandas as pd
import prep
t=pd.read_csv("../gbm-pasir43mg2.csv", na_filter=False)
cd=prep.clean_ticket_text(t['DESCRIPTION'])
cr=prep.clean_ticket_text(t['DESCRIPTION'])
#pd.DataFrame(cd).to_csv('t2.csv')
prep.write_text_for_pv(cd, "cd.txt")
prep.write_text_for_pv(cr, "cr.txt")
