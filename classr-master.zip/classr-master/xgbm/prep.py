import pandas as pd
import csv

def clean_ticket_text(text_col):
	# generic cleansing ========================================
    # duplicate space removal
    text_col = text_col.str.replace(" +"," ")
    # newline removal
    text_col = text_col.str.replace("[\\r\\n]+"," ")
    #_camelCase_ => _camel_Case_
    text_col = text_col.str.replace(" ([a-zA-Z][a-z]+)([A-Z][a-z]+) ", " \\1 \\2 ")
    # ----------------------------------------------------------    
    text_col = text_col.str.lower()
    # ----------------------------------------------------------    
    # date/time generic
    text_col = text_col.str.replace("(20)?\\d?\\d[\\/\\-]\\d?\\d[\\/\\-](20)?\\d?\\d (\\d)?\\d[\\: ]\\d\\d([\\: ]\\d\\d)?( ?[ap]m)?", " [DATETIME] ")
    # tiemstamp: Sun Feb 9 22:55:07 MST 2014
    text_col = text_col.str.replace("[mtwfs]\\w{2} [jfmasond]\\w{2} \\d\\d? (\\d)?\\d\\:\\d\\d\\:\\d\\d \\w+ (20)?\\d\\d", " [DATETIME] ")
    # tiemstamp: Sun 9 Feb 2014 2:55:07 AM MST
    text_col = text_col.str.replace("[mtwfs]\\w{2} \\d?\\d [jfmasond]\\w{2} (20)?\\d\\d? (\\d)?\\d\\:\\d\\d\\:\\d\\d( ?[ap]m)? [a-z]{3,4}", " [DATETIME] ")
    # date generic
    text_col = text_col.str.replace("(20)?\\d?\\d[\\/\\-]\\d?\\d[\\/\\-](20)?\\d?\\d", " [DATE] ")
    # date: Jan 1, 2015
    text_col = text_col.str.replace("(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|noc|dec) \\d\\d?. ?(20)?\\d\\d", " [DATE] ")
    # date: January 1, 2015
    text_col = text_col.str.replace("(jan(uary)?|feb(ruary)?|mar(ch)?|apr(il)?|may|june?|july?|aug(ust)?|sep(tember)?|oct(ober)?|nov(ember)?|dec(ember)?) \\d\\d?. ?(20)?\\d\\d", " [DATE] ")
    # time
    text_col = text_col.str.replace("(\\d)?\\d\\:\\d\\d(\\:\\d\\d)?( ?[ap]m)?", " [TIME] ")
    # ----------------------------------------------------------    
    # email
    text_col = text_col.str.replace("[\\W\\s]\\[EMAIL\\]\\@\\S+", " [EMAIL] ")         
    text_col = text_col.str.replace(" [a-z0-9\\.\\-\\_]+\\@[a-z0-9\\.\\-]+ ", " [EMAIL] ")
    # ----------------------------------------------------------    
    # ipaddr
    text_col = text_col.str.replace("[12]?\\d?\\d\\.[12]?\\d?\\d\\.[12]?\\d?\\d\\.[12]?\\d?\\d", " [IPADDR] ")
    # ----------------------------------------------------------    
    # URL
    text_col = text_col.str.replace("https?\\:\\/\\/\\S+", " [URL] ")
    # ----------------------------------------------------------    
    # 9% => 9_percent_
    text_col = text_col.str.replace("(\\d) ?\\%", "\\1 percent ")
    # ----------------------------------------------------------    
    # a/a => a_a
    text_col = text_col.str.replace("(\\w)[\\/\\:\\=\\*\\(\\)\\<\\>\\_](\\w)", "\\1 \\2")
    # * => _
    text_col = text_col.str.replace("[*\\(\\)\\<\\>\\_]", " ")
    #  _:)_ => _
    text_col = text_col.str.replace("\\s[\\W]+\\s", " ")
    # a)_ => a_
    text_col = text_col.str.replace("(\\w)[\\:\\,\"\\'\\)\\/\\*\\>\\}]+[\\.?!\\s]", "\\1 ")
    # _(a => _a
    text_col = text_col.str.replace(" [\\.\\:\\,\"\\'\\(\\/\\*\\<\\{\\-]+(\\w)", " \\1")
    # ----------------------------------------------------------    
    text_col = text_col.str.replace("\\[(NAME|DATE|TIME|DATETIME|EMAIL|IPADDR|URL)\\]", "@\\1@")
    text_col = text_col.str.replace("[\\[\\]]", " ")
    text_col = text_col.str.replace("\\@(NAME|DATE|TIME|DATETIME|EMAIL|IPADDR|URL)\\@", "[\\1]")
	# generic cleansing ========================================
    # text_col = text_col.str.lower()
    text_col = text_col.str.replace("^[a-z][a-z0-9\\-]{3,}\\d+[a-z]{0,2}(\\.[a-z0-9\\-]+)* ","[hostname] ")
    text_col = text_col.str.replace(" [a-z][a-z0-9\\-]{3,}\\d+[a-z]{0,2}(\\.[a-z0-9\\-]+)* "," [hostname] ")
    text_col = text_col.str.replace(" [a-z][a-z0-9\\-]{3,}\\d+[a-z]{0,2}(\\.[a-z0-9\\-]+)* "," [hostname] ")
	# organize ========================================
    # leading special chars
    text_col = text_col.str.replace("^[^a-zA-Z0-9\\[]+","")
    # trailing special chars
    text_col = text_col.str.replace("[^a-zA-Z0-9\\]]+$","")
    # long string
    text_col = text_col.str.replace("\\S{20,}","[LONG]")
    # contraction tokenization
    text_col = text_col.str.replace("(\\w)\\'(\\w)","\\1 '\\2")
    # hard-remove any special chars left
    text_col = text_col.str.replace("[^a-zA-Z0-9\\'\\.\\[\\]]"," ")
    # a. => a_
    text_col = text_col.str.replace("([a-zA-Z])[\\.\\,]","\\1 ")
    # duplicate space removal
    text_col = text_col.str.replace(" +"," ")
    text_col = text_col.str.replace("\\[TIME\\] \\[DATE\\]", "[DATETIME]")
    text_col = text_col.str.replace("\\[DATE\\] \\[TIME\\]", "[DATETIME]")
    text_col = text_col.str.replace("\\[name\\]", "[NAME]")
    text_col = text_col.str.replace("\\[DATE\\]", "[DATE]")
    text_col = text_col.str.replace("\\[TIME\\]", "[TIME]")
    text_col = text_col.str.replace("\\[datetime\\]", "[DATETIME]")
    text_col = text_col.str.replace("\\[email\\]", "[EMAIL]")
    text_col = text_col.str.replace("\\[ipaddr\\]", "[IPADDR]")
    text_col = text_col.str.replace("\\[url\\]", "[URL]")
    text_col = text_col.str.replace("\\[hostname\\]", "[HOSTNAME]")
	# replace numeric ========================================
    text_col = text_col.str.replace("^(.)", " \\1")
    text_col = text_col.str.replace("(.)$", "\\1 ")
    text_col = text_col.str.replace(" ", "  ")
    # xyzabcde.fg -> [x.y#B]
    text_col = text_col.str.replace(" 0*([1-9])(\\d)\\d\\d\\d\\d\\d\\d\\d(\\.\\d+)?([a-zA-Z]*) ", " [\\1.\\2#B] \\4 ")
    # xyzabcde.fg -> [xy#M]
    text_col = text_col.str.replace(" 0*([1-9]\\d)\\d\\d\\d\\d\\d\\d\\d(\\.\\d+)?([a-zA-Z]*) ", " [\\1#M] \\4 ")
    # xyzabcde.fg -> [xy.#M]
    text_col = text_col.str.replace(" 0*([1-9]\\d)\\d\\d\\d\\d\\d\\d(\\.\\d+)?([a-zA-Z]*) ", " [\\1.#M] \\3 ")
    # xyzabcd.ef -> [x.y#M]
    text_col = text_col.str.replace(" 0*([1-9])(\\d)\\d\\d\\d\\d\\d(\\.\\d+)?([a-zA-Z]*) ", " [\\1.\\2#M] \\4 ")
    # xyzabc.de -> [xy#k]
    text_col = text_col.str.replace(" 0*([1-9]\\d)\\d\\d\\d\\d(\\.\\d+)?([a-zA-Z]*) ", " [\\1#k] \\3 ")
    # xyzab.cd -> [xy.#k]
    text_col = text_col.str.replace(" 0*([1-9]\\d)\\d\\d\\d(\\.\\d+)?([a-zA-Z]*) ", " [\\1.#k] \\3 ")
    # xyza.bc -> [x.y#k]
    text_col = text_col.str.replace(" 0*([1-9])(\\d)\\d\\d(\\.\\d+)?([a-zA-Z]*) ", " [\\1.\\2#k] \\4 ")
    # xyz.ab -> [xy#]
    text_col = text_col.str.replace(" 0*([1-9]\\d)\\d(\\.\\d+)?([a-zA-Z]*) ", " [\\1#] \\3 ")
    # xy.za -> [xy.#]
    text_col = text_col.str.replace(" 0*([1-9]\\d)(\\.\\d+)?([a-zA-Z]*) ", " [\\1.#] \\3 ")
    # x.yz -> [x.y#] 
    text_col = text_col.str.replace(" 0*(\\d\\.\\d)\\d*([a-zA-Z]*) ", " [\\1#] \\2 ")
    # x -> [x.0#]
    text_col = text_col.str.replace(" 0*(\\d)([a-zA-Z]*) ", " [\\1.0#] \\2 ") 
    # anything larger -> [LNUM]
    #text_col = text_col.str.replace("[^\\[]?\\d+(\\.\\d+)?([a-zA-Z]*) ", " [LNUM] \\2 ")
    text_col = text_col.str.strip()
    # duplicate space removal
    text_col = text_col.str.replace(" +"," ")
    return text_col


def write_text_for_pv(clean_text_col, file_name):
    text_out = ["_*"+str(i)+" "+str(clean_text_col[i]) for i in xrange(clean_text_col.count())]
    with open(file_name, 'w') as file:
        for item in text_out:
            file.write("{}\n".format(item))    


def open_and_clean_ticket_csv(in_csv, 
                     desc_col='DESCRIPTION', 
                     res_col='RESOLUTION',
                     clean_desc_col='CLEAN_DESCRIPTION',
                     clean_res_col='CLEAN_RESOLUTION',
                     clean_combined_col='CLEAN_COMBINED',
                     verbose=False):
   # read data
   if (verbose) : print 'Opening', in_csv
   tickets_csv = pd.read_csv(in_csv, na_filter=False)
   # clean description
   tickets_csv[clean_desc_col] = tickets_csv[desc_col]
   if (verbose) : print 'Cleaning', desc_col
   tickets_csv[clean_desc_col] = clean_ticket_text(tickets_csv[clean_desc_col])
   # clean resolution
   tickets_csv[clean_res_col] = tickets_csv[res_col]
   if (verbose) : print 'Cleaning', res_col
   tickets_csv[clean_res_col] = clean_ticket_text(tickets_csv[clean_res_col])
   # prepare combined clean column
   if (verbose) : print 'Combining cleaned columns'
   tickets_csv[clean_combined_col] = tickets_csv[clean_desc_col] + ' ' + tickets_csv[clean_res_col]
   tickets_csv[clean_combined_col] = tickets_csv[clean_combined_col].str.strip()
   return tickets_csv


