MERGE INTO PASIR.TICKET AS t 
   USING (VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)) AS new (
      CLASSR_TICKETCLASSIFICATION_ID,
      ID,
      CLASSIFICATION,
      P_DISK,
      P_NONACT,
      P_OTHER,
      P_PERF,
      P_PROC,
      P_SU,
      CLEAN,
      QUALITY_ISSUE)
      ON t.ID = new.ID
   WHEN MATCHED THEN UPDATE SET 
      t.CLASSR_TICKETCLASSIFICATION_ID = new.CLASSR_TICKETCLASSIFICATION_ID,
      t.CLASSIFICATION = new.CLASSIFICATION,
      t.P_DISK = new.P_DISK,
      t.P_NONACT = new.P_NONACT,
      t.P_OTHER = new.P_OTHER,
      t.P_PERF = new.P_PERF,
      t.P_PROC = new.P_PROC,
      t.P_SU = new.P_SU,
      t.CLEAN = new.CLEAN,
      t.QUALITY_ISSUE = new.QUALITY_ISSUE,
      t.CLASSR_TS = CURRENT TIMESTAMP
   ELSE IGNORE
