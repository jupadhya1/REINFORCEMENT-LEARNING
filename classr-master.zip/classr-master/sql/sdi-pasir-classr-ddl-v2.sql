-- DDL for creating the required columns for PASIR's ticket classifier in SDI
--
-- Please substitute any missing table names in the script.
--
-- David Lanyi | dla@zurich.ibm.com
-- Predictive Analytics for Server Incident Reduction
-- IBM Research Zurich

CREATE TABLE "PASIR".CLASSR_TICKETCLASSIFICATION
(
   ID                              INTEGER         GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
   CREATEDDATE                     TIMESTAMP       DEFAULT CURRENT TIMESTAMP,
   CLASSR_MODEL_CD                 VARCHAR(36)     NOT NULL,
   JOB_UID                         VARCHAR(36)     NOT NULL,
   CLIENT_ID                       CHAR(15),
   DATA_SOURCE                     CHAR(16),
   TS_FROM                         TIMESTAMP,
   TS_TO                           TIMESTAMP,
   TICKET_COUNT                    INTEGER,
   STATE                           VARCHAR(50)     DEFAULT 'Created',
   STATUS_TEXT                     VARCHAR(1000),
   STATUS_PERCENT                  INTEGER         DEFAULT 0,
   STATUS_UPDATED                  TIMESTAMP       DEFAULT CURRENT TIMESTAMP
);

ALTER TABLE "PASIR".CLASSR_TICKETCLASSIFICATION
   ADD PRIMARY KEY (ID);

COMMIT;

ALTER TABLE PASIR.TICKET
  ADD COLUMN CLASSR_TICKETCLASSIFICATION_ID   INTEGER,
  ADD COLUMN CLASSR_TS                        TIMESTAMP,
  ADD COLUMN CLASSIFICATION                   VARCHAR(30),
  ADD COLUMN P_DISK                           REAL,
  ADD COLUMN P_NONACT                         REAL,
  ADD COLUMN P_OTHER                          REAL,
  ADD COLUMN P_PERF                           REAL,
  ADD COLUMN P_PROC                           REAL,
  ADD COLUMN P_SU                             REAL,
  ADD COLUMN CLEAN                            CHAR(1),
  ADD COLUMN QUALITY_ISSUE                    VARCHAR(50);

ALTER TABLE PASIR.TICKET
  ADD CONSTRAINT "PASIR_TICKET_TICKETCLASSIFICATION_FK" FOREIGN KEY (CLASSR_TICKETCLASSIFICATION_ID)
  REFERENCES "PASIR"."CLASSR_TICKETCLASSIFICATION" (ID)
  ON UPDATE NO ACTION
  ON DELETE RESTRICT;

COMMIT;